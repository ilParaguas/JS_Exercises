# JSON methods

Create the `fromJson` method that takes in a json as parameter and returns an object of type `Person`.
