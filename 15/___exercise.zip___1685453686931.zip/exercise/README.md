# Array Methods Advanced

Create a function called `sortPeopleByAge` that returns the people in ascending order by age.
