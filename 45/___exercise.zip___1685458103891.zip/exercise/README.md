# DOM

Get the value of the `firstName` text input field and print it in the console.

Use the `id` as selector.
