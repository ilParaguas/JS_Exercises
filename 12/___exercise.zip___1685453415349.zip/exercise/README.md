# Array Methods Advanced

Create a function called `nicknameMap` that takes in an array of people and returns an array of nicknames. The nickname should be composed in this way: `<name>-<age>`.

Example:

```
{ name: 'Paul', age: 21 } => Paul-21
```
