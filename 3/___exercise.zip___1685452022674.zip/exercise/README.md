# Arrow functions

Turn the variables functions into arrow functions and combine the functions so that the result of the following mathematical operation is printed on the console: `((2 + 4) * (5 + 2) - 2) / 5`
