function sumUntil(maxValue) {
  // ...
}

console.log(sumUntil(5));