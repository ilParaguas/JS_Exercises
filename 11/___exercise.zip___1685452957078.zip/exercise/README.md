# Array Methods Advanced

Create a function called `adultFilter` that takes in an array of people and returns the ones who are of age.
