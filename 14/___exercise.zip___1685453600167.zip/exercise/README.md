# Array Methods Advanced

Create a function called `uncompletedNotes` that returns only not completed todos.

**Suggestion**

Use the forEach and filter arrays methods.
