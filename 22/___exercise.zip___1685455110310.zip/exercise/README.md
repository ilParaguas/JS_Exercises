# Destructuring

Use the destructuring to assign the values just with one code line.
