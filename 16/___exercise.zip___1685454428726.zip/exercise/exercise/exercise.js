// Class definition

const developer = new Person('Mario', 'Rossi');
console.log(developer.firstName + " " + developer.lastName);
