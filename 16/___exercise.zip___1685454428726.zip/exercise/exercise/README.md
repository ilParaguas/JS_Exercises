# Classes

Define a class called `Person` that takes in two arguments (`firstName` and `lastName`) in the constructor.

const developer = new Person('Mario', 'Rossi');
console.log(developer.firstName + " " + developer.lastName);
