# Network Requests

Using async and await, implement the necessary code to recover the Todo with ID 4 through the following URL: [link](https://jsonplaceholder.typicode.com/todos/4) . Then create two elements:An `<h2>` element containing the Todo title (title property)
An `<Input Type = "Checkbox"> `with the Checked property set to the value present for the complete property of the Todo
Append the two elements previously created inside the container.
