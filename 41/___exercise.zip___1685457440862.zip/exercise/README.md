# Network Requests

Using async and await, implement the necessary code to perform an HTTP POST request. To create a new post, use the following URL: [link](https://jsonplaceholder.typicode.com/posts) (Method: Post). The body of the request must contain a post object with the following information: title and Flag Completed. The post data must be transmitted following the compilation of a form.
