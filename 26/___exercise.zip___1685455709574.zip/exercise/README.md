# Rest parameters and spread syntax

The sum function has a high numbers of parameters. How can we improve the code in order to make it accept any amount of numbers to sum as its argument?
