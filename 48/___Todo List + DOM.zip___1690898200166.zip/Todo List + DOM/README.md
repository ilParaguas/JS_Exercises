# Network Requests - Todo List + DOM

Starting from the exercise called 'Network Requests - Todo List', create dynamically a list of elements `<li>` containing the Todo title (title property in the collection of objects returned by the Response) and append it to the '.todo-list' element.
N.B: The Body of the Response contains the Todos list in Json format, use the .json method present in the response to perform the deserialization.
