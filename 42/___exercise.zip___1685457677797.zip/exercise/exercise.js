const user = {
  id: 1,
  name: "John",
  age: 25,
};
