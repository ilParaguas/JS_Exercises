# Object Methods

Create an object `person`. Print its key/value pair in the console. Try to use the method `Object.kyes`:

```
firstName: Mario
lastName: Rossi
age: 25
```
