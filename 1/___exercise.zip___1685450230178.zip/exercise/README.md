# Conditionals & Loops

Create a function named `calculateSalary` which takes an input parameter, and calculates and returns the corresponding salary. You must use the `switch` switch statement.
For each role the corresponding salary is as follows:

- ceo => 2200€
- manager => 1800€
- cto => 1800€
- developer => 1500€
- default => 1000€
