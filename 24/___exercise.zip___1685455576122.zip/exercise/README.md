# Destructuring

The destructuring returns undefined for the properties: name, surname and old. Try fixing the code without changing the any of the object properties in the constant { id, name, surname, old }.
