# JSON methods

Convert the `developer` object into json.
