function multiplyByTwo(value) {
  let number = 2;
}
