# Object Copying

In this exercise we have created two objects: `person1` e `person2`. The object `person2` has been assigned to the object `person1`. You should modify the property `firstName` of the object `person2` in "Simon".

Write a comment explaining why, by modifying the object `person2`, also the object `person1` would be modified.
