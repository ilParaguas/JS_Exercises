# JSON methods

In this exercise we need to filter the properties of the object person in order to convert just the id and age values into JSON.
